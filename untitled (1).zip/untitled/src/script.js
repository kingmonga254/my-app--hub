
// scripts.js

// Function to handle the game play (when clicked on a game button)
function playApp(appName) {
    alert(`Launching ${appName}...`);
    // You can redirect to a new page or embed the game iframe here
    // Example: window.location.href = `/play/${appName}`;
}

// Function to handle the search bar functionality
function searchApp() {
    var url = document.getElementById("app-url").value.trim();
    var errorMessage = document.getElementById("search-error");
    var embedSection = document.getElementById("app-embed");

    // Simple URL validation (you can improve this later)
    var regex = /^(https?:\/\/)?(www\.)?[a-z0-9]+(\.[a-z]{2,})+([\/\w \.-]*)*\/?$/;
    
    // Clear previous errors and embeds
    errorMessage.style.display = "none";
    embedSection.innerHTML = "";

    if (regex.test(url)) {
        // Create the iframe element and embed the app/game
        var iframe = document.createElement("iframe");
        iframe.src = url;
        iframe.width = "100%";
        iframe.height = "600";
        embedSection.appendChild(iframe);
    } else {
        // Display an error if the URL is invalid
        errorMessage.style.display = "block";
    }
}
